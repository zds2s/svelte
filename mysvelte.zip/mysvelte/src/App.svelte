<script>
  import catLogo from './assets/cat.jpeg'
  import dogLogo from './assets/dog.jpeg'
  
  
</script>



<main>
  <div>
    <a href="./lib/Login.svelte" target="_blank" rel="noreferrer">
      <img src={catLogo} class="logo" alt="Cat Logo" />
    </a>
    <a href="./lib/Todos.svelte" target="_blank" rel="noreferrer">
      <img src={dogLogo} class="logo svelte" alt="Dog Logo" />
    </a>
  </div>
  <h1>Welcome to pets record</h1>

  <p>
    Click on the Dog and Cat logo to find more.

  </p>

  
</main>

<style>
  .logo {
    height: 6em;
    padding: 1.5em;
    will-change: filter;
    transition: filter 300ms;
  }
  .logo:hover {
    filter: drop-shadow(0 0 2em #646cffaa);
  }
  .logo.svelte:hover {
    filter: drop-shadow(0 0 2em #ff3e00aa);
  }
  
</style>
