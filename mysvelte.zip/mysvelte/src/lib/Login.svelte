<script>
  let username = '';
  let password = '';

  function handleSubmit() {
    alert('Username:${username},Password:${password}');
  }
</script>

<main>
  <h1>Login</h1>
  <from on:submit|preventDefault={handleSubmit}>
    <label for="username">Username:</label>
    <input type="password" id="password" bind:value={username} required>

    <button type="submit">Login</button>
  </from>
</main>

